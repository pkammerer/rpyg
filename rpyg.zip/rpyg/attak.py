from  model.enemy import Enemy

enemy = Enemy(200,60)

print(enemy.get_hp())