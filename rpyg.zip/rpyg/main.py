from model.game import Person, bcolors
from model.magic import Spell
from model.inventory import Item


# Evocation spells
fire = Spell("Firebolto", 5, 50,"black")
thunder = Spell("Impactrueno", 10, 100,"black")
blizzard = Spell("Hielo", 10, 100,"black")
meteor = Spell("Nuke", 20, 220,"black")
quake = Spell("Terrremoto ", 15, 160,"black")

# Restoration spells
cure = Spell("Cure",12,120,"white")
cura = Spell("Rest. todo",18,200, "white")

#Items
potion = Item("Potion","potion","Heals 50 HP",50)
hipotion = Item("Hi-Potion", "potion","Heals 100 HP",100)
superpotion = Item("Super-Potion", "potion","Heals 150 HP",150)
elixer = Item("Elixer", "elixer","Fully restoresHP/MP",9999)
hielixer = Item("MegaElixer","elixer","Fully restores the party HP/MP",9999)

grenade = Item("Grenade","attack","Deals 100 damage to all enemies",100)

#---------------------------------------------------------------------------------

# Cosas PJ
player_spells = [fire,blizzard,cure,meteor]
player_items = [{"item":potion ,"quantity":5},{"item":hipotion,"quantity":2},{"item":elixer,"quantity":1},{"item":grenade,"quantity":2}]

# Personajes
player = Person(460,65,60,34,player_spells, player_items)
enemy = Person(1200,65,45,25, 1,[])

running = True
i = 0

print(bcolors.FAIL + bcolors.BOLD + "AN ENEMY ATTACKS" + bcolors.ENDC )

while running:
    print("==================")
    player.choose_action()
    choice = input("Choose action: ")
    index = int(choice) - 1

    # Primera decision
    if index == 0:
        dmg = player.generate_damage()
        enemy.take_damage(dmg)
        print("You attacked for", dmg,"points of damage.")
    elif index == 1:
        
        # Decision magia
        print("---------------------")
        player.choose_magic()
        magic_choice =int(input("Choose magic:"))-1
        
        if magic_choice == -1:
            continue

        spell = player.magic[magic_choice]
        magic_dmg = player.magic[magic_choice].generate_damage()

        if spell.cost > player.get_mp():
            print(bcolors.FAIL + "\nNotenough MP\n+bcolors.ENDC")
            continue
        
        player.reduce_mp(spell.cost)

        if spell.type == "white":
            player.heal(magic_dmg)
            print(bcolors.OKBLUE + "\n"+spell.name+" heals for",str(magic_dmg),"HP."+bcolors.ENDC)
        elif spell.type == "black":
            enemy.take_damage(magic_dmg)
            print(bcolors.OKBLUE + "\n"+spell.name+ " deals",str(magic_dmg),"points of damage" + bcolors.ENDC)
    
    elif index == 2:
        # Decision objetos
        player.choose_items()
        item_choice = int(input("Choose item: ")) -1
        item = player.items[item_choice]

        if  item_choice == -1:
            continue

        if item["item"].type == "potion":
            player.heal(item["item"].prop)
            print(bcolors.OKGREEN +"\n"+item["item"].name+" heals for",str(item["item"].prop),"HP" +bcolors.ENDC)
        elif item["item"].type == "elixer":
            player.hp = player.maxHp
            player.mp = player.maxMp
            print(print(bcolors.OKGREEN + "\n"+item["item"].name+ " fully restores HP/MP"+bcolors.ENDC))
        elif item["item"].type == "attack":
            enemy.take_damage(item["item"].prop)
            print(bcolors.FAIL + "\n"+item["item"].name+" deals",str(item["item"].prop),"points of damage"+bcolors.ENDC)
                
        player.items[item_choice]["quantity"]-=1

    #Ataque del enemigo
    enemy_choice = 1

    enemy_dmg = enemy.generate_damage()
    player.take_damage(enemy_dmg)
    print("Enemy attacks for",enemy_dmg)

    # Info de estados
    print("--------------------")
    print("Enemy HP", bcolors.FAIL + str(enemy.get_hp()) +"/"+str(enemy.get_max_hp())+bcolors.ENDC+"\n")
    print("Your HP", bcolors.OKGREEN + str(player.get_hp()) +"/"+str(player.get_max_hp())+bcolors.ENDC)
    print("Your MP", bcolors.OKBLUE + str(player.get_mp()) +"/"+str(player.get_max_mp())+bcolors.ENDC+"\n")
    if  enemy.get_hp() == 0:
        print(bcolors.OKGREEN + "You win!" + bcolors.ENDC)
        running = False
    elif player.get_hp() == 0:
        print(bcolors.FAIL +"Your enemy has defeated you!" + bcolors.ENDC)
        running = False 

