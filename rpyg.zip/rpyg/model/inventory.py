class Item:
    def __init__(self,name,tipo,description,prop):
        self.name = name
        self.type = tipo
        self.description = description
        self.prop = prop

    